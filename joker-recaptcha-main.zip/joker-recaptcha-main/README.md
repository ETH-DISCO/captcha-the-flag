# Joker reCaptcha
Joker (fake) reCaptcha

演示地址 [gh-page joker-recaptcha](https://qiangmouren.github.io/joker-recaptcha/)

正如你所看到的，怎么选都不对，结果就像个小丑（Joker）

![](https://s3.bmp.ovh/imgs/2022/07/27/4217470c36ba88f5.gif)